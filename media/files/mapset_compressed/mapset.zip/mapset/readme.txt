If you do not have the FLASH PLUGIN for your computer, go here and you will be able to download the latest version of the FLASH player for your computer!

thank you!


http://www.macromedia.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash